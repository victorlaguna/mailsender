# python-bulk-mail
A simple python script to send bulk emails.
